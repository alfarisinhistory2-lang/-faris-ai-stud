import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import multer from "multer";
import { query, pool } from "./db.js";

const app = express();
const port = process.env.PORT || 10000;
const token = process.env.API_ACCESS_TOKEN || "";
const origins = (process.env.CORS_ORIGINS || "*").split(",").map(x => x.trim());

app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || origins.includes("*") || origins.includes(origin)) return cb(null, true);
    return cb(new Error("Origin not allowed"));
  }
}));
app.use(express.json({ limit: "2mb" }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 12 * 1024 * 1024, files: 1 }
});

function auth(req, res, next) {
  if (!token) return res.status(503).json({ error: "API_ACCESS_TOKEN is not configured" });
  const supplied = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (supplied !== token) return res.status(401).json({ error: "غير مصرح" });
  next();
}

app.get("/health", async (_req, res) => {
  try {
    await query("SELECT 1");
    res.json({ ok: true, service: "FARIS AI STUDIO API", database: "connected" });
  } catch {
    res.status(503).json({ ok: false, database: "disconnected" });
  }
});

app.post("/api/lessons", auth, async (req, res) => {
  const { grade, term, unit_name, lesson_name, source_text } = req.body || {};
  if (!grade || !lesson_name || !source_text?.trim()) {
    return res.status(400).json({ error: "الصف واسم الدرس ونص المصدر مطلوبة" });
  }
  const result = await query(
    `INSERT INTO lessons(grade,term,unit_name,lesson_name,source_text)
     VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [grade, term || null, unit_name || null, lesson_name, source_text]
  );
  res.status(201).json({ lesson: result.rows[0] });
});

app.get("/api/lessons", auth, async (_req, res) => {
  const result = await query(
    "SELECT id,grade,term,unit_name,lesson_name,approved,created_at FROM lessons ORDER BY created_at DESC LIMIT 100"
  );
  res.json({ lessons: result.rows });
});

app.post("/api/lessons/:id/approve", auth, async (req, res) => {
  const result = await query(
    "UPDATE lessons SET approved=TRUE,updated_at=NOW() WHERE id=$1 RETURNING id,approved",
    [req.params.id]
  );
  if (!result.rowCount) return res.status(404).json({ error: "الدرس غير موجود" });
  res.json({ lesson: result.rows[0] });
});

app.post("/api/production/jobs", auth, async (req, res) => {
  const { lesson_id } = req.body || {};
  if (!lesson_id) return res.status(400).json({ error: "lesson_id مطلوب" });
  const lesson = await query("SELECT id,approved FROM lessons WHERE id=$1", [lesson_id]);
  if (!lesson.rowCount) return res.status(404).json({ error: "الدرس غير موجود" });
  if (!lesson.rows[0].approved) {
    return res.status(409).json({ error: "يجب اعتماد محتوى الدرس قبل بدء الإنتاج" });
  }
  const result = await query(
    `INSERT INTO production_jobs(lesson_id) VALUES($1) RETURNING id,status,progress,stage,created_at`,
    [lesson_id]
  );
  res.status(202).json({ job: result.rows[0] });
});

app.get("/api/production/jobs/:id", auth, async (req, res) => {
  const result = await query("SELECT * FROM production_jobs WHERE id=$1", [req.params.id]);
  if (!result.rowCount) return res.status(404).json({ error: "المهمة غير موجودة" });
  res.json({ job: result.rows[0] });
});

app.get("/api/videos", auth, async (_req, res) => {
  const result = await query(
    `SELECT id,lesson_id,video_url,completed_at FROM production_jobs
     WHERE status='completed' ORDER BY completed_at DESC LIMIT 100`
  );
  res.json({ videos: result.rows });
});

app.get("/api/notifications", auth, async (_req, res) => {
  const result = await query(
    "SELECT * FROM app_notifications ORDER BY created_at DESC LIMIT 100"
  );
  res.json({ notifications: result.rows });
});

// This endpoint stores text extracted by a trusted PDF/OCR process.
// PDF parsing/OCR is intentionally not faked in this starter package.
app.post("/api/source-text", auth, upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "أرفق ملفاً" });
  res.status(501).json({
    error: "استخراج PDF/OCR غير مفعّل في هذه النسخة. أرسل النص المستخرج أو اربط خدمة استخراج موثوقة.",
    fileName: req.file.originalname,
    receivedBytes: req.file.size
  });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "حدث خطأ داخلي" });
});

const server = app.listen(port, () => console.log(`FARIS API listening on ${port}`));
process.on("SIGTERM", async () => {
  server.close();
  await pool.end();
  process.exit(0);
});
